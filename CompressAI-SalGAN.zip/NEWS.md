2021-12-23: Compressai v1.2.0 now includes video bench pipeline and the Scale-Space-Flow model [Agustsson et al. 2020]
            The license has been changed BSD-3-Clause-Clear

2021-03-05: CompressAI is now available on PyPI!

2021-01-26: Experimental multi-GPU support
* `aux_parameters` was dropped to support data parallel
* see the updated example/train.py
* use `load_pretrained` to convert `state_dict`s to the new format

2020-06-21: First release of CompressAI !
