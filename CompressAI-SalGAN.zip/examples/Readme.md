# Examples

## Notebooks

To run the jupyter notebooks:

* `pip install -U ipython jupyter ipywidgets matplotlib`
* `jupyter notebook`
