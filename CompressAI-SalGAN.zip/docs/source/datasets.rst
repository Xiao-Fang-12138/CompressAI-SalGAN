compressai.datasets
===================

.. currentmodule:: compressai.datasets


ImageFolder
-----------
.. autoclass:: ImageFolder
    :members:


VideoFolder
-----------
.. autoclass:: VideoFolder
    :members: