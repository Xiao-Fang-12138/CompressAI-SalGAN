compressai.entropy_models
=========================

.. currentmodule:: compressai.entropy_models


EntropyBottleneck
-----------------
.. autoclass:: EntropyBottleneck


GaussianConditional
-------------------
.. autoclass:: GaussianConditional
