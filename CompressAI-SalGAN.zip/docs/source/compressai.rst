compressai
==========
.. automodule:: compressai
   :members:
