compressai.ops
==============

.. currentmodule:: compressai.ops


ste_round
---------
.. autofunction:: ste_round

LowerBound
----------
.. autoclass:: LowerBound


NonNegativeParametrizer
-----------------------
.. autoclass:: NonNegativeParametrizer
